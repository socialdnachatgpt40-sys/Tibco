import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { About } from './components/About';
import { Services } from './components/Services';
import { Projects } from './components/Projects';
import { Contact } from './components/Contact';
import { Footer } from './components/Footer';
import { ProductsPage } from './components/pages/ProductsPage';
import { ProductDetailPage } from './components/pages/ProductDetailPage';
import { AboutUsPage } from './components/pages/AboutUsPage';
import { OEMPage } from './components/pages/OEMPage';
import { Product } from './types';

function App() {
  const [currentView, setCurrentView] = useState<'home' | 'products' | 'product-detail' | 'about' | 'oem'>('home');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  const handleNavigate = (view: string) => {
    // Handle Hash Links (Scroll to section)
    if (view.startsWith('#')) {
      const targetId = view;
      
      // If we are not on home, go there first
      if (currentView !== 'home') {
        setCurrentView('home');
        setSelectedProduct(null);
        // Wait for render cycle then scroll
        setTimeout(() => {
          const element = document.querySelector(targetId);
          if (element) element.scrollIntoView({ behavior: 'smooth' });
        }, 100);
      } else {
        // We are already on home, just scroll
        const element = document.querySelector(targetId);
        if (element) element.scrollIntoView({ behavior: 'smooth' });
      }
      return;
    }

    // Handle View Switching
    window.scrollTo({ top: 0, behavior: 'smooth' });
    
    if (view === 'products') {
      setCurrentView('products');
      setSelectedProduct(null);
    } else if (view === 'about') {
      setCurrentView('about');
      setSelectedProduct(null);
    } else if (view === 'oem') {
      setCurrentView('oem');
      setSelectedProduct(null);
    } else {
      setCurrentView('home');
      setSelectedProduct(null);
    }
  };

  const handleProductSelect = (product: Product) => {
    setSelectedProduct(product);
    setCurrentView('product-detail');
    window.scrollTo(0, 0);
  };

  const handleBackToProducts = () => {
    setCurrentView('products');
    setSelectedProduct(null);
  };

  return (
    <div className="min-h-screen bg-slate-50 text-[#0e253d] selection:bg-[#F2B544] selection:text-[#0e253d]">
      <Navbar onNavigate={handleNavigate} />
      <main>
        {currentView === 'home' && (
          <>
            <Hero onNavigate={handleNavigate} />
            <About onNavigate={handleNavigate} />
            {/* Services is now Product Categories */}
            <Services onNavigate={handleNavigate} />
            {/* Projects is now Featured Products */}
            <Projects onNavigate={handleNavigate} />
            <Contact />
          </>
        )}
        {currentView === 'products' && (
          <ProductsPage onProductSelect={handleProductSelect} />
        )}
        {currentView === 'about' && (
          <AboutUsPage onNavigate={handleNavigate} />
        )}
        {currentView === 'oem' && (
          <OEMPage onNavigate={handleNavigate} />
        )}
        {currentView === 'product-detail' && selectedProduct && (
          <ProductDetailPage 
            product={selectedProduct} 
            onBack={handleBackToProducts}
            onNavigate={handleNavigate}
          />
        )}
      </main>
      <Footer onNavigate={handleNavigate} />
    </div>
  );
}

export default App;