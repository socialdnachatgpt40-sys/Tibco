import { LucideIcon } from 'lucide-react';

export interface NavItem {
  label: string;
  href: string;
}

export interface ProductCategory {
  id: string;
  title: string;
  description: string;
  image: string;
  link: string;
}

export interface FeaturedProduct {
  id: string;
  model: string;
  title: string;
  description: string;
  image: string;
  category: string;
}

export interface Stat {
  value: string;
  label: string;
}

export interface ProductSpec {
  label: string;
  value: string;
}

export interface Product {
  id: string;
  model: string;
  name: string;
  category: string;
  image: string;
  description: string;
  features: string[]; // For card view (bullet points)
  detailedSpecs: ProductSpec[]; // For detail page (table)
}