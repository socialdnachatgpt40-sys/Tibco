import { Product } from '../types';

export const products: Product[] = [
  // Ceiling Fans
  {
    id: 'c1',
    model: 'TCF-03',
    name: 'Premium Ceiling Fan',
    category: 'Ceiling Fans',
    image: 'https://tibcogroup.com/wp-content/uploads/2025/09/tibco-banner3.jpg',
    features: ['900mm Sweep', 'High Speed', 'Copper Motor'],
    description: 'A perfect blend of style and cooling efficiency for modern living spaces. Designed to provide superior air delivery with silent operation.',
    detailedSpecs: [
      { label: 'Motor Options', value: 'High Speed / Normal Speed' },
      { label: 'Blade Material', value: 'Aluminum' },
      { label: 'Top & Bottom Cover', value: 'Aluminum' },
      { label: 'Air Delivery (Min.)', value: '230 CMM' },
      { label: 'Bearing Type', value: 'Double Ball Bearing' },
      { label: 'Sweep Sizes', value: '900 mm | 1200 mm' }
    ]
  },
  {
    id: 'c2',
    model: 'TCF-01',
    name: 'Classic Ceiling Fan',
    category: 'Ceiling Fans',
    image: 'https://tibcogroup.com/wp-content/uploads/2025/09/1.png',
    features: ['1200mm Sweep', 'Energy Efficient', 'Double Ball Bearing'],
    description: 'Reliable air circulation with a timeless design suitable for any room. Built with high-grade materials for long-lasting performance.',
    detailedSpecs: [
      { label: 'Motor Options', value: 'High Speed / Normal Speed' },
      { label: 'Blade Material', value: 'CRCA' },
      { label: 'Top & Bottom Cover', value: 'CRCA' },
      { label: 'Air Delivery (Min.)', value: '210 CMM' },
      { label: 'Bearing Type', value: 'Double Bearing' },
      { label: 'Sweep Sizes', value: '900 mm | 1200 mm | 1400 mm' }
    ]
  },
  // TPW Fans
  {
    id: 't1',
    model: 'TT-01',
    name: 'Table Fan Pro',
    category: 'TPW Fans',
    image: 'https://tibcogroup.com/wp-content/uploads/2025/09/tibco-banner1.jpg',
    features: ['400mm Sweep', 'Oscillation', '3-Speed Control'],
    description: 'Engineered for personal cooling comfort with silent operation. Portable and powerful.',
    detailedSpecs: [
      { label: 'Sweep Size', value: '400 mm' },
      { label: 'Motor Type', value: 'High Speed Copper' },
      { label: 'Speed Control', value: '3 Speed Piano Switch' },
      { label: 'Oscillation', value: '60 Degree Jerk-free' },
      { label: 'Grill', value: '120 Spokes Guard' },
      { label: 'Body Material', value: 'ABS Plastic' }
    ]
  },
  {
    id: 't2',
    model: 'TP-01',
    name: 'Pedestal Air King',
    category: 'TPW Fans',
    image: 'https://tibcogroup.com/wp-content/uploads/2025/09/tibco-banner2.jpg',
    features: ['High Velocity', 'Adjustable Height', 'Heavy Base'],
    description: 'Robust pedestal fan designed for high airflow in larger areas. Adjustable height and tilt mechanism.',
    detailedSpecs: [
      { label: 'Sweep Size', value: '400 mm / 450 mm' },
      { label: 'Height', value: 'Adjustable Telescopic' },
      { label: 'Base', value: 'Heavy Round Base' },
      { label: 'RPM', value: '1350 / 2100' },
      { label: 'Power Consumption', value: '55W - 110W' }
    ]
  },
  {
    id: 't3',
    model: 'TW-01',
    name: 'Wall Mount Breeze',
    category: 'TPW Fans',
    image: 'https://tibcogroup.com/wp-content/uploads/2025/09/2.png',
    features: ['Remote Control', 'Timer', 'Space Saving'],
    description: 'Ideal for offices and homes where floor space is at a premium. Comes with pull cords for speed and oscillation.',
    detailedSpecs: [
      { label: 'Sweep Size', value: '400 mm' },
      { label: 'Mounting', value: 'Wall Bracket' },
      { label: 'Operation', value: 'Remote / Pull Cord' },
      { label: 'Tilt Angle', value: 'Adjustable' },
      { label: 'Motor Protection', value: 'Thermal Overload Protector' }
    ]
  },
  // Exhaust
  {
    id: 'e1',
    model: 'TEX-HS09',
    name: 'High-Speed Exhaust',
    category: 'Exhaust Fans',
    image: 'https://tibcogroup.com/wp-content/uploads/2025/09/tibco-banner4.jpg',
    features: ['9-inch Blade', 'Metal Body', '2800 RPM'],
    description: 'Compact metal exhaust fan ensuring rapid ventilation for kitchens and bathrooms. High RPM motor for quick suction.',
    detailedSpecs: [
      { label: 'Sweep Size', value: '225 mm (9 inch)' },
      { label: 'Speed', value: '2800 RPM' },
      { label: 'Body', value: 'Metal with Powder Coating' },
      { label: 'Noise Level', value: 'Low Noise Design' },
      { label: 'Application', value: 'Kitchens, Bathrooms, Cabins' }
    ]
  },
  {
    id: 'e2',
    model: 'TEX-HD12',
    name: 'Heavy Duty Exhaust',
    category: 'Exhaust Fans',
    image: 'https://tibcogroup.com/wp-content/uploads/2025/09/3.png',
    features: ['12-inch Blade', 'Industrial Grade', 'Anti-Corrosive'],
    description: 'Powerful extraction for warehouses, factories, and commercial kitchens. Built to withstand continuous operation.',
    detailedSpecs: [
      { label: 'Sweep Size', value: '300 mm / 375 mm / 450 mm' },
      { label: 'Motor', value: 'Heavy Duty Double Ball Bearing' },
      { label: 'Construction', value: 'Steel Body & Blades' },
      { label: 'Air Delivery', value: 'High Volume' },
      { label: 'Protection', value: 'Bird Guard Mesh (Optional)' }
    ]
  },
  // Ventilation
  {
    id: 'v1',
    model: 'TV-01',
    name: 'Domestic Ventilator',
    category: 'Ventilation Fans',
    image: 'https://tibcogroup.com/wp-content/uploads/2025/09/4.png',
    features: ['Silent Operation', 'Plastic Body', 'Easy Clean'],
    description: 'Keeps your indoor air fresh and free from odors and humidity. Stylish design matches modern interiors.',
    detailedSpecs: [
      { label: 'Sweep Size', value: '150 mm / 200 mm / 250 mm' },
      { label: 'Material', value: 'High Grade PP' },
      { label: 'Shutters', value: 'Automatic Louvers' },
      { label: 'Installation', value: 'Window / Glass / Wall' },
      { label: 'Maintenance', value: 'Easy to Dismantle & Clean' }
    ]
  },
];

export const categories = ['All', 'Ceiling Fans', 'TPW Fans', 'Exhaust Fans', 'Ventilation Fans'];