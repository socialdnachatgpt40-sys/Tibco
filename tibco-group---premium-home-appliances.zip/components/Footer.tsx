import React from 'react';
import { Facebook, Twitter, Linkedin, Instagram, ArrowUp } from 'lucide-react';

interface FooterProps {
  onNavigate: (view: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleLinkClick = (href: string) => {
    onNavigate(href);
  };

  const handleSubscribe = () => {
    alert("You have successfully subscribed to our newsletter!");
  };

  return (
    <footer className="bg-[#081c2c] text-slate-400 pt-20 pb-10 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          
          {/* Brand */}
          <div className="space-y-6">
            <button onClick={() => handleLinkClick('home')} className="flex items-center gap-2">
              <img 
                src="https://tibcogroup.com/wp-content/uploads/2025/08/Asset-7@300x-8.png" 
                alt="Tibco" 
                className="h-10 w-auto" 
              />
            </button>
            <p className="text-sm leading-relaxed">
              Powering Dreams since 1975. One of the leading brands in India known for reliable, durable, and performance-worthy electrical home appliances.
            </p>
            <div className="flex gap-4">
              <a href="#" className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center hover:bg-[#F2B544] hover:text-[#0e253d] transition-all"><Facebook size={18} /></a>
              <a href="#" className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center hover:bg-[#F2B544] hover:text-[#0e253d] transition-all"><Twitter size={18} /></a>
              <a href="#" className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center hover:bg-[#F2B544] hover:text-[#0e253d] transition-all"><Linkedin size={18} /></a>
              <a href="#" className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center hover:bg-[#F2B544] hover:text-[#0e253d] transition-all"><Instagram size={18} /></a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-white font-bold mb-6 text-lg">Quick Links</h4>
            <ul className="space-y-3 text-sm">
              <li><button onClick={() => handleLinkClick('home')} className="hover:text-[#F2B544] transition-colors">Home</button></li>
              <li><button onClick={() => handleLinkClick('about')} className="hover:text-[#F2B544] transition-colors">About Us</button></li>
              <li><button onClick={() => handleLinkClick('products')} className="hover:text-[#F2B544] transition-colors">Products</button></li>
              <li><button onClick={() => handleLinkClick('oem')} className="hover:text-[#F2B544] transition-colors">OEM Services</button></li>
              <li><button onClick={() => handleLinkClick('#contact')} className="hover:text-[#F2B544] transition-colors">Contact</button></li>
            </ul>
          </div>

          {/* Products */}
          <div>
            <h4 className="text-white font-bold mb-6 text-lg">Product Categories</h4>
            <ul className="space-y-3 text-sm">
              <li><button onClick={() => handleLinkClick('products')} className="hover:text-[#F2B544] transition-colors">Ceiling Fans</button></li>
              <li><button onClick={() => handleLinkClick('products')} className="hover:text-[#F2B544] transition-colors">TPW Fans</button></li>
              <li><button onClick={() => handleLinkClick('products')} className="hover:text-[#F2B544] transition-colors">Ventilation Fans</button></li>
              <li><button onClick={() => handleLinkClick('products')} className="hover:text-[#F2B544] transition-colors">Heavy Duty Exhaust</button></li>
              <li><button onClick={() => handleLinkClick('products')} className="hover:text-[#F2B544] transition-colors">Domestic Exhaust</button></li>
            </ul>
          </div>

          {/* Newsletter */}
          <div>
            <h4 className="text-white font-bold mb-6 text-lg">Newsletter</h4>
            <p className="text-sm mb-4">Subscribe for the latest product updates and catalogues.</p>
            <div className="flex">
              <input 
                type="email" 
                placeholder="Email Address" 
                className="bg-slate-800 border border-slate-700 rounded-l-md px-4 py-2 text-sm w-full focus:outline-none focus:border-[#F2B544] transition-colors"
              />
              <button 
                onClick={handleSubscribe}
                className="bg-[#F2B544] text-[#0e253d] font-bold px-4 py-2 rounded-r-md hover:bg-[#d99f33] transition-colors"
              >
                Join
              </button>
            </div>
          </div>
        </div>

        <div className="border-t border-slate-800 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-xs">© {new Date().getFullYear()} Tibco Group. All rights reserved.</p>
          <div className="flex gap-6 text-xs">
            <a href="#" className="hover:text-white" onClick={(e) => e.preventDefault()}>Terms & Conditions</a>
            <a href="#" className="hover:text-white" onClick={(e) => e.preventDefault()}>Legal</a>
            <a href="#" className="hover:text-white" onClick={(e) => e.preventDefault()}>Sitemap</a>
          </div>
          <button 
            onClick={scrollToTop}
            className="w-10 h-10 bg-slate-800 rounded-sm flex items-center justify-center hover:bg-[#F2B544] hover:text-[#0e253d] transition-all group"
          >
            <ArrowUp size={20} className="group-hover:-translate-y-1 transition-transform" />
          </button>
        </div>
      </div>
    </footer>
  );
};