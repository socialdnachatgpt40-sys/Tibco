import React from 'react';
import { motion } from 'framer-motion';

const clients = [
  'https://tibcogroup.com/wp-content/uploads/2025/08/2-2.png',
  'https://tibcogroup.com/wp-content/uploads/2025/08/1-2.png',
  'https://tibcogroup.com/wp-content/uploads/2025/08/3-3.png',
  'https://tibcogroup.com/wp-content/uploads/2025/08/4-1.png',
];

export const Clientele: React.FC = () => {
  // Triple the list to ensure smooth seamless looping
  const marqueeList = [...clients, ...clients, ...clients, ...clients];

  return (
    <div className="py-16 bg-white border-t border-slate-100 overflow-hidden relative">
      <div className="max-w-7xl mx-auto px-4 md:px-8 mb-12 text-center">
        <h3 className="text-2xl font-serif font-bold text-[#0e253d]">Trusted by Leading Brands</h3>
        <div className="w-16 h-1 bg-[#F2B544] mx-auto mt-4 rounded-full"></div>
      </div>
      
      <div className="relative w-full overflow-hidden">
        {/* Gradients to fade edges */}
        <div className="absolute top-0 left-0 h-full w-20 bg-gradient-to-r from-white to-transparent z-10 pointer-events-none"></div>
        <div className="absolute top-0 right-0 h-full w-20 bg-gradient-to-l from-white to-transparent z-10 pointer-events-none"></div>

        <motion.div
          className="flex gap-16 items-center w-max"
          animate={{ x: ["0%", "-50%"] }}
          transition={{ 
            repeat: Infinity, 
            duration: 30, 
            ease: "linear" 
          }}
        >
          {marqueeList.map((logo, index) => (
            <div 
              key={index} 
              className="flex-shrink-0 w-40 h-24 flex items-center justify-center grayscale hover:grayscale-0 transition-all duration-300 opacity-60 hover:opacity-100 transform hover:scale-110 cursor-pointer"
            >
              <img 
                src={logo} 
                alt="Client Logo" 
                className="max-w-full max-h-full object-contain" 
              />
            </div>
          ))}
        </motion.div>
      </div>
    </div>
  );
};