import React, { useState, useEffect } from 'react';
import { Menu, X, ArrowRight } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { NavItem } from '../types';

const navItems: NavItem[] = [
  { label: 'Home', href: 'home' },
  { label: 'Products', href: 'products' },
  { label: 'OEM Services', href: 'oem' },
  { label: 'About Us', href: 'about' },
  { label: 'Contact', href: '#contact' },
];

interface NavbarProps {
  onNavigate: (view: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onNavigate }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleLinkClick = (href: string) => {
    setIsMobileMenuOpen(false);
    onNavigate(href);
  };

  return (
    <header
      className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${
        isScrolled ? 'bg-[#0e253d]/95 backdrop-blur-md py-3 shadow-lg' : 'bg-[#0e253d]/90 py-6'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 md:px-8 flex justify-between items-center">
        {/* Logo */}
        <button onClick={() => handleLinkClick('home')} className="flex items-center gap-2 group relative z-50">
          <img 
            src="https://tibcogroup.com/wp-content/uploads/2025/08/Asset-7@300x-8.png" 
            alt="Tibco Group" 
            className="h-12 w-auto object-contain"
          />
        </button>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center gap-8">
          {navItems.map((item) => (
            <button
              key={item.label}
              onClick={() => handleLinkClick(item.href)}
              className="text-slate-200 hover:text-[#F2B544] text-sm font-semibold tracking-wide transition-colors relative group font-manrope"
            >
              {item.label}
              <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-[#F2B544] transition-all duration-300 group-hover:w-full" />
            </button>
          ))}
          <button
            onClick={() => handleLinkClick('#contact')}
            className="px-6 py-2.5 bg-[#F2B544] hover:bg-[#d99f33] text-[#0e253d] font-bold text-sm rounded-full transition-all flex items-center gap-2 transform hover:scale-105"
          >
            Get a Quote <ArrowRight size={16} />
          </button>
        </nav>

        {/* Mobile Menu Button */}
        <button
          className="md:hidden text-white z-50 relative"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          {isMobileMenuOpen ? <X size={28} /> : <Menu size={28} />}
        </button>
      </div>

      {/* Mobile Menu Overlay */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, x: '100%' }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: '100%' }}
            transition={{ type: 'tween', duration: 0.3 }}
            className="fixed inset-0 bg-[#0e253d] z-40 flex flex-col p-8 md:hidden"
          >
            <div className="flex flex-col gap-8 mt-20">
              {navItems.map((item, idx) => (
                <motion.button
                  key={item.label}
                  onClick={() => handleLinkClick(item.href)}
                  initial={{ opacity: 0, x: 50 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: idx * 0.1 }}
                  className="text-3xl text-white font-serif hover:text-[#F2B544] transition-colors text-left"
                >
                  {item.label}
                </motion.button>
              ))}
            </div>
            <div className="mt-auto">
               <p className="text-slate-400 text-sm mb-2">Need assistance?</p>
               <p className="text-xl text-[#F2B544] font-medium">+91 92810 96258</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
};