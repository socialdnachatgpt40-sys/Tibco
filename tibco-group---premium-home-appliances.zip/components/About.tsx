import React from 'react';
import { motion } from 'framer-motion';
import { Section } from './ui/Section';
import { CheckCircle2, Factory, Award, Users } from 'lucide-react';
import { Stat } from '../types';

interface AboutProps {
  onNavigate: (view: string) => void;
}

const stats: Stat[] = [
  { value: '1975', label: 'Established In' },
  { value: '50+', label: 'Years of Excellence' },
  { value: '1M+', label: 'Units Delivered' },
  { value: '100%', label: 'Quality Assured' },
];

export const About: React.FC<AboutProps> = ({ onNavigate }) => {
  return (
    <Section id="about">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
        <motion.div
          initial={{ opacity: 0, x: -50 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <div className="relative">
            <span className="relative z-10 text-[#F2B544] font-bold tracking-widest uppercase text-sm">Our Legacy</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-serif font-bold text-[#0e253d] mt-4 mb-6 leading-tight">
            Quality Electrical <br/>Home Appliances <span className="text-[#F2B544]">Since 1975</span>
          </h2>
          <p className="text-slate-600 text-lg leading-relaxed mb-6">
            Tibco has been known for its quality Electrical Home Appliances. We are one of the leading brands in India and are notable for our reliable, durable, and performance-worthy appliances.
          </p>
          <p className="text-slate-600 text-lg leading-relaxed mb-8">
            The journey of the company began in 1975 as a small business. Since then, product advancement and the delivery of high-quality appliances have consistently boosted our pace in the market.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
             {[
               "State-of-the-Art Manufacturing",
               "Advanced R&D Facility",
               "Premium OEM Services",
               "Pan-India Presence"
             ].map((item, index) => (
               <div key={index} className="flex items-center gap-3">
                 <CheckCircle2 className="text-[#0e253d] flex-shrink-0" size={20} />
                 <span className="text-slate-800 font-medium">{item}</span>
               </div>
             ))}
          </div>

          <button 
            onClick={() => onNavigate('about')}
            className="text-[#0e253d] font-bold hover:text-[#F2B544] flex items-center gap-2 group transition-colors"
          >
            Read more about our journey 
            <span className="group-hover:translate-x-1 transition-transform">→</span>
          </button>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="relative"
        >
            <div className="relative rounded-2xl overflow-hidden shadow-2xl border-8 border-white">
               <img 
                 src="https://tibcogroup.com/wp-content/uploads/2025/09/Comp-1_01159.jpg" 
                 alt="State of the art manufacturing" 
                 className="w-full h-auto object-cover"
               />
               <div className="absolute inset-0 bg-gradient-to-t from-[#0e253d] to-transparent opacity-60"></div>
               <div className="absolute bottom-8 left-8 text-white">
                  <Factory className="mb-2 text-[#F2B544]" size={32} />
                  <h3 className="text-2xl font-bold">Manufacturing Excellence</h3>
                  <p className="text-slate-200">High-capacity production lines</p>
               </div>
            </div>
            
            {/* Experience Badge */}
            <div className="absolute -top-6 -right-6 bg-[#F2B544] text-[#0e253d] p-6 rounded-full shadow-xl text-center w-32 h-32 flex flex-col justify-center items-center z-10">
              <Award className="mb-1" size={24} />
              <div className="text-xl font-bold leading-none">Top</div>
              <div className="text-xs font-bold uppercase">Brand</div>
            </div>
        </motion.div>
      </div>

      {/* Stats Counter */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mt-24 border-t border-slate-200 pt-12">
        {stats.map((stat, idx) => (
          <motion.div
            key={idx}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: idx * 0.1, duration: 0.6 }}
            className="text-center"
          >
            <div className="text-4xl md:text-5xl font-serif font-bold text-[#0e253d] mb-2">{stat.value}</div>
            <div className="text-slate-500 font-medium uppercase tracking-wider text-sm">{stat.label}</div>
          </motion.div>
        ))}
      </div>
    </Section>
  );
};