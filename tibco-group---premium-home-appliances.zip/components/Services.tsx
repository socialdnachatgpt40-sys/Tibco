import React from 'react';
import { motion } from 'framer-motion';
import { Section } from './ui/Section';
import { ArrowUpRight } from 'lucide-react';
import { ProductCategory } from '../types';

interface ServicesProps {
  onNavigate: (view: string) => void;
}

const categories: ProductCategory[] = [
  {
    id: '1',
    title: 'Ceiling Fans',
    description: 'Stylish and energy-efficient, designed to complement any interior while delivering powerful air circulation.',
    image: 'https://tibcogroup.com/wp-content/uploads/2025/09/1.png',
    link: 'products'
  },
  {
    id: '2',
    title: 'TPW Fans',
    description: 'Table, Pedestal & Wall Fans bring flexibility and convenience to your space. Targeted airflow wherever you need it.',
    image: 'https://tibcogroup.com/wp-content/uploads/2025/09/2.png',
    link: 'products'
  },
  {
    id: '3',
    title: 'Ventilation Fans',
    description: 'Improve indoor air quality by efficiently removing stale air, smoke, and odors from your home.',
    image: 'https://tibcogroup.com/wp-content/uploads/2025/09/4.png',
    link: 'products'
  },
  {
    id: '4',
    title: 'Exhaust Fans',
    description: 'Built for heavy-duty performance, ensuring effective air extraction in commercial and industrial spaces.',
    image: 'https://tibcogroup.com/wp-content/uploads/2025/09/3.png',
    link: 'products'
  },
];

export const Services: React.FC<ServicesProps> = ({ onNavigate }) => {
  return (
    <Section id="products" dark className="relative">
      <div className="text-center mb-20 max-w-3xl mx-auto">
        <span className="text-[#F2B544] font-bold tracking-widest uppercase text-sm">Our Collection</span>
        <h2 className="text-4xl md:text-5xl font-serif font-bold text-white mt-4 mb-6">
          Premium <span className="text-[#F2B544]">Cooling Solutions</span>
        </h2>
        <p className="text-slate-400 text-lg">
          Explore our diverse range of high-performance fans designed for every need.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {categories.map((cat, idx) => (
          <motion.div
            key={cat.id}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: idx * 0.1, duration: 0.5 }}
            className="group relative bg-[#1e3a5a] rounded-2xl p-6 hover:-translate-y-2 transition-transform duration-300 border border-slate-700 hover:border-[#F2B544] cursor-pointer"
            onClick={() => onNavigate('products')}
          >
            <div className="absolute top-4 right-4 bg-[#F2B544] rounded-full p-2 opacity-0 group-hover:opacity-100 transition-opacity">
              <ArrowUpRight size={20} className="text-[#0e253d]" />
            </div>

            <div className="h-48 flex items-center justify-center mb-6 relative">
               <div className="absolute inset-0 bg-[#F2B544]/20 rounded-full blur-[40px] scale-0 group-hover:scale-100 transition-transform duration-500"></div>
               <img 
                 src={cat.image} 
                 alt={cat.title} 
                 className="w-auto h-full max-h-44 object-contain relative z-10 transition-transform duration-500 group-hover:scale-110 group-hover:rotate-3" 
               />
            </div>

            <h3 className="text-2xl font-bold text-white mb-3">{cat.title}</h3>
            <p className="text-slate-400 text-sm leading-relaxed mb-6 line-clamp-3">
              {cat.description}
            </p>
            
            <button className="inline-flex items-center text-[#F2B544] font-bold text-sm uppercase tracking-wide group-hover:underline">
              View Products
            </button>
          </motion.div>
        ))}
      </div>
    </Section>
  );
};