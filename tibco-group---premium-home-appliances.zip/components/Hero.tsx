import React from 'react';
import { motion } from 'framer-motion';
import { ArrowDown, Wind } from 'lucide-react';

interface HeroProps {
  onNavigate: (view: string) => void;
}

export const Hero: React.FC<HeroProps> = ({ onNavigate }) => {
  return (
    <section id="home" className="relative h-screen min-h-[800px] flex items-center justify-center overflow-hidden bg-[#0e253d]">
      {/* Abstract Background Shapes */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-[-20%] right-[-10%] w-[50%] h-[50%] bg-[#F2B544] opacity-10 rounded-full blur-[100px]" />
        <div className="absolute bottom-[-10%] left-[-10%] w-[40%] h-[40%] bg-blue-500 opacity-10 rounded-full blur-[120px]" />
      </div>

      <div className="max-w-7xl mx-auto px-4 md:px-8 w-full relative z-10 pt-20 grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
        
        {/* Text Content */}
        <div className="order-2 lg:order-1">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <div className="flex items-center gap-2 mb-6">
              <span className="h-px w-10 bg-[#F2B544]"></span>
              <span className="text-[#F2B544] font-semibold tracking-widest uppercase text-sm">Expert OEM Supplier</span>
            </div>
            
            <h1 className="text-5xl md:text-7xl font-serif font-bold text-white leading-tight mb-6">
              Elevate Your <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#F2B544] to-[#f5cd7a]">
                Airflow
              </span>
              <br /> Experience!
            </h1>
          </motion.div>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2, duration: 0.8 }}
            className="text-lg text-slate-300 leading-relaxed mb-10 max-w-xl"
          >
            Designed for style, built for durability. Trusted by thousands of homes for unmatched airflow and energy efficiency. Powering premium brand performance.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 0.8 }}
            className="flex flex-wrap gap-4"
          >
            <button 
              onClick={() => onNavigate('products')}
              className="px-8 py-4 bg-[#F2B544] hover:bg-[#d99f33] text-[#0e253d] font-bold rounded-full transition-all transform hover:-translate-y-1 shadow-[0_10px_20px_-10px_rgba(242,181,68,0.5)]"
            >
              Explore Products
            </button>
            <button 
              onClick={() => onNavigate('#contact')}
              className="px-8 py-4 bg-transparent border border-slate-600 text-white hover:border-[#F2B544] hover:text-[#F2B544] font-bold rounded-full transition-all"
            >
              Partner With Us
            </button>
          </motion.div>
        </div>

        {/* Image Content */}
        <div className="order-1 lg:order-2 relative flex justify-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1 }}
            className="relative z-10"
          >
            {/* Spinning Animation Wrapper */}
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ repeat: Infinity, duration: 20, ease: "linear" }}
              className="relative z-10"
            >
               <img 
                src="https://comparable-pink-6bbkulapfx-i58e0o4vu3.edgeone.dev/Untitled%20design%20(16).png" 
                alt="Premium Fan" 
                className="w-full max-w-[500px] h-auto object-contain drop-shadow-2xl"
              />
            </motion.div>
            
            {/* Floating Badges */}
            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.8 }}
              className="absolute top-10 right-0 md:-right-10 bg-white/10 backdrop-blur-md border border-white/20 p-4 rounded-xl text-white max-w-[150px]"
            >
              <Wind className="text-[#F2B544] mb-2" />
              <p className="font-bold text-sm">Silent Spin Technology</p>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 1 }}
              className="absolute bottom-10 left-0 md:-left-10 bg-white/10 backdrop-blur-md border border-white/20 p-4 rounded-xl text-white max-w-[150px]"
            >
              <div className="text-[#F2B544] font-bold text-2xl mb-1">100%</div>
              <p className="text-xs text-slate-300">Energy Efficient Copper Motor</p>
            </motion.div>
          </motion.div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.5 }}
        className="absolute bottom-10 left-1/2 transform -translate-x-1/2 z-10 text-slate-400 flex flex-col items-center gap-2 cursor-pointer"
        onClick={() => onNavigate('#about')}
      >
        <span className="text-[10px] tracking-widest uppercase">Scroll</span>
        <motion.div
          animate={{ y: [0, 8, 0] }}
          transition={{ repeat: Infinity, duration: 2, ease: "easeInOut" }}
        >
          <ArrowDown size={16} />
        </motion.div>
      </motion.div>
    </section>
  );
};