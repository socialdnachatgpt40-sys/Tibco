import React, { useEffect } from 'react';
import { motion } from 'framer-motion';
import { ChevronRight, Target, Eye } from 'lucide-react';
import { Clientele } from '../Clientele';
import { Contact } from '../Contact';

interface AboutUsPageProps {
  onNavigate: (view: string) => void;
}

export const AboutUsPage: React.FC<AboutUsPageProps> = ({ onNavigate }) => {
    useEffect(() => {
        window.scrollTo(0, 0);
    }, []);

    const team = [
        {
            name: "Manoj Tibrewala",
            role: "Chairman & Managing Director (CMD), Founder",
            image: "https://tibcogroup.com/wp-content/uploads/2025/09/manoj-tiberwala-1.png",
            desc: "Mr. Manoj Tibrewala, the visionary founder of our company, established the organization with a strong belief in innovation, quality, and integrity. With his rich experience and professional qualifications, he has laid the foundation for sustainable growth and excellence in the electric fan industry."
        },
        {
            name: "Sri Akshat Tibrewala",
            role: "Managing Director (MD)",
            image: "https://tibcogroup.com/wp-content/uploads/2025/08/team1-400-x-400-px-1.png",
            desc: "Mr. Akshat Tibrewala represents the next generation of leadership, combining modern vision with the company’s strong legacy. His focus lies in blending sustainability with technology to create products of global standards."
        },
        {
            name: "Ms. Nidhi Tibrewala",
            role: "Business Finance Head",
            image: "https://tibcogroup.com/wp-content/uploads/2025/08/305.png",
            desc: "Ms. Nidhi Tibrewala plays a pivotal role in controlling and managing the company’s financial operations. With her strong academic background and professional qualifications, she ensures that the financial systems remain robust, transparent, and growth-oriented."
        }
    ];

    return (
        <div className="pt-24 min-h-screen bg-slate-50">
            {/* Header */}
            <div className="bg-[#0e253d] text-white py-16 px-4 md:px-8 relative overflow-hidden">
                <div className="max-w-7xl mx-auto relative z-10 text-center">
                    <h1 className="text-4xl md:text-6xl font-serif font-bold mb-6">About Us</h1>
                    <div className="flex justify-center items-center gap-2 text-sm text-slate-300">
                        <button onClick={() => onNavigate('home')} className="hover:text-[#F2B544] transition-colors">Home</button>
                        <ChevronRight size={14} />
                        <span className="text-[#F2B544] font-medium">About Us</span>
                    </div>
                </div>
            </div>

            {/* Intro Section */}
            <div className="max-w-7xl mx-auto px-4 md:px-8 py-20">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                    <motion.div initial={{ opacity: 0, x: -30 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }}>
                        <h2 className="text-3xl md:text-4xl font-bold text-[#0e253d] mb-6">Powering Dreams <span className="text-[#F2B544]">Since 1975</span></h2>
                        <p className="text-slate-600 mb-6 leading-relaxed text-lg">
                            Tibco has been known for its quality Electrical Home Appliances. We are one of the leading brands in India and are notable for our reliable, durable and performance-worthy appliances.
                        </p>
                        <p className="text-slate-600 mb-6 leading-relaxed">
                            The journey of the company began in 1975, when it was established as a small business. Since then, the product advancement and high-quality appliances delivered by us, has always boosted our pace in the market. With our rich history of success and reliability, we have, over the years, also earned the trust and reputation from our clients.
                        </p>
                        <p className="text-slate-600 leading-relaxed font-semibold">
                            We own four manufacturing plants in Noida (Uttar Pradesh) for meeting the standards and the demands of quality appliances.
                        </p>
                    </motion.div>
                    <motion.div initial={{ opacity: 0, scale: 0.9 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once: true }} className="relative">
                        <div className="absolute inset-0 bg-[#F2B544] rounded-2xl transform rotate-3 opacity-20"></div>
                        <img 
                            src="https://tibcogroup.com/wp-content/uploads/2025/09/about-us-tibco-img.png" 
                            alt="About Tibco" 
                            className="relative z-10 rounded-2xl shadow-xl w-full object-cover"
                        />
                    </motion.div>
                </div>
            </div>

            {/* Mission & Vision */}
            <div className="bg-white py-20 border-y border-slate-100">
                <div className="max-w-7xl mx-auto px-4 md:px-8 grid grid-cols-1 md:grid-cols-2 gap-8">
                    <motion.div 
                        initial={{ opacity: 0, y: 30 }} 
                        whileInView={{ opacity: 1, y: 0 }} 
                        viewport={{ once: true }}
                        className="bg-slate-50 p-8 rounded-2xl border border-slate-200 hover:border-[#F2B544] transition-colors group"
                    >
                        <div className="w-16 h-16 bg-[#0e253d] rounded-full flex items-center justify-center text-[#F2B544] mb-6 group-hover:bg-[#F2B544] group-hover:text-[#0e253d] transition-colors">
                            <Target size={32} />
                        </div>
                        <h3 className="text-2xl font-bold text-[#0e253d] mb-4">Our Mission</h3>
                        <p className="text-slate-600 leading-relaxed">
                            Empowering every Indian home with reliable, innovative, and sustainable electrical appliances—championing superior quality, cutting-edge technology, and a commitment to green manufacturing for a brighter future.
                        </p>
                    </motion.div>

                    <motion.div 
                        initial={{ opacity: 0, y: 30 }} 
                        whileInView={{ opacity: 1, y: 0 }} 
                        viewport={{ once: true }}
                        transition={{ delay: 0.2 }}
                        className="bg-slate-50 p-8 rounded-2xl border border-slate-200 hover:border-[#F2B544] transition-colors group"
                    >
                        <div className="w-16 h-16 bg-[#0e253d] rounded-full flex items-center justify-center text-[#F2B544] mb-6 group-hover:bg-[#F2B544] group-hover:text-[#0e253d] transition-colors">
                            <Eye size={32} />
                        </div>
                        <h3 className="text-2xl font-bold text-[#0e253d] mb-4">Our Vision</h3>
                        <p className="text-slate-600 leading-relaxed">
                            To be India's most trusted and innovative leader in electrical home appliances, delivering unmatched value, sustainability, and comfort, while exceeding the expectations of our customers, partners, and communities.
                        </p>
                    </motion.div>
                </div>
            </div>

            {/* Roadmap */}
            <div className="py-20 max-w-7xl mx-auto px-4 md:px-8">
                <div className="text-center mb-12">
                    <span className="text-[#F2B544] font-bold tracking-widest uppercase text-sm">Our Journey</span>
                    <h2 className="text-3xl md:text-4xl font-serif font-bold text-[#0e253d] mt-2">Milestones of Success</h2>
                </div>
                <motion.div 
                    initial={{ opacity: 0, y: 30 }} 
                    whileInView={{ opacity: 1, y: 0 }} 
                    viewport={{ once: true }}
                    className="rounded-2xl overflow-hidden shadow-2xl"
                >
                    <img 
                        src="https://tibcogroup.com/wp-content/uploads/2025/09/road-map-tibco.jpg" 
                        alt="Tibco Roadmap" 
                        className="w-full h-auto"
                    />
                </motion.div>
            </div>

            {/* Team */}
            <div className="bg-slate-100 py-20">
                <div className="max-w-7xl mx-auto px-4 md:px-8">
                    <div className="text-center mb-16">
                        <span className="text-[#F2B544] font-bold tracking-widest uppercase text-sm">Leadership</span>
                        <h2 className="text-3xl md:text-4xl font-serif font-bold text-[#0e253d] mt-2">Meet Our Team</h2>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                        {team.map((member, idx) => (
                            <motion.div 
                                key={idx}
                                initial={{ opacity: 0, y: 20 }}
                                whileInView={{ opacity: 1, y: 0 }}
                                viewport={{ once: true }}
                                transition={{ delay: idx * 0.1 }}
                                className="bg-white rounded-2xl overflow-hidden shadow-lg group hover:-translate-y-2 transition-transform duration-300"
                            >
                                <div className="aspect-square overflow-hidden bg-slate-200">
                                    <img 
                                        src={member.image} 
                                        alt={member.name} 
                                        className="w-full h-full object-cover object-top transition-transform duration-500 group-hover:scale-105"
                                    />
                                </div>
                                <div className="p-6">
                                    <h3 className="text-xl font-bold text-[#0e253d] mb-1">{member.name}</h3>
                                    <p className="text-[#F2B544] font-bold text-sm mb-4">{member.role}</p>
                                    <p className="text-slate-600 text-sm leading-relaxed mb-4">
                                        {member.desc}
                                    </p>
                                </div>
                            </motion.div>
                        ))}
                    </div>
                </div>
            </div>

            <Clientele />
            <Contact />
        </div>
    );
};