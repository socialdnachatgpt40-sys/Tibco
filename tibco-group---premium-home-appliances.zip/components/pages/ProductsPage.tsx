import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, ArrowRight, Wind, Zap, ShieldCheck } from 'lucide-react';
import { products, categories } from '../../data/products';
import { Product } from '../../types';

interface ProductsPageProps {
  onProductSelect: (product: Product) => void;
}

export const ProductsPage: React.FC<ProductsPageProps> = ({ onProductSelect }) => {
  const [activeCategory, setActiveCategory] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredProducts = products.filter(product => {
    const matchesCategory = activeCategory === 'All' || product.category === activeCategory;
    const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          product.model.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="pt-24 min-h-screen bg-slate-50">
      {/* Header */}
      <div className="bg-[#0e253d] text-white py-16 px-4 md:px-8 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-[#F2B544] rounded-full blur-[100px] opacity-20 pointer-events-none" />
        <div className="max-w-7xl mx-auto relative z-10 text-center">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl md:text-6xl font-serif font-bold mb-6"
          >
            Our Product <span className="text-[#F2B544]">Catalog</span>
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-slate-300 text-lg max-w-2xl mx-auto"
          >
            Discover our comprehensive range of high-performance air solutions designed for residential, commercial, and industrial applications.
          </motion.p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 md:px-8 py-12">
        {/* Controls */}
        <div className="flex flex-col md:flex-row justify-between items-center gap-6 mb-12">
          {/* Categories */}
          <div className="flex flex-wrap justify-center gap-2">
            {categories.map(cat => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-5 py-2.5 rounded-full text-sm font-bold transition-all ${
                  activeCategory === cat
                    ? 'bg-[#0e253d] text-white shadow-lg'
                    : 'bg-white text-slate-600 hover:bg-[#F2B544] hover:text-[#0e253d] border border-slate-200'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Search */}
          <div className="relative w-full md:w-auto min-w-[300px]">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400" size={20} />
            <input 
              type="text" 
              placeholder="Search by model or name..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-3 rounded-full border border-slate-200 focus:outline-none focus:border-[#F2B544] focus:ring-1 focus:ring-[#F2B544] transition-all"
            />
          </div>
        </div>

        {/* Grid */}
        <motion.div 
          layout
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8"
        >
          <AnimatePresence mode='popLayout'>
            {filteredProducts.map((product) => (
              <motion.div
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.3 }}
                key={product.id}
                className="group bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl border border-slate-100 transition-all duration-300 hover:-translate-y-1 flex flex-col"
              >
                <div 
                  className="relative h-64 bg-slate-100 p-6 flex items-center justify-center overflow-hidden cursor-pointer"
                  onClick={() => onProductSelect(product)}
                >
                  <div className="absolute top-4 right-4 z-10 bg-white/80 backdrop-blur-sm px-2 py-1 rounded text-[10px] font-bold uppercase tracking-wider text-[#0e253d]">
                    {product.category}
                  </div>
                  <img 
                    src={product.image} 
                    alt={product.name} 
                    className="w-full h-full object-contain transform group-hover:scale-110 transition-transform duration-500"
                  />
                </div>
                
                <div className="p-6 flex flex-col flex-grow">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="text-xl font-bold text-[#0e253d] group-hover:text-[#F2B544] transition-colors">{product.name}</h3>
                    <span className="text-xs font-bold text-slate-400 bg-slate-100 px-2 py-1 rounded">{product.model}</span>
                  </div>
                  
                  <p className="text-slate-500 text-sm mb-4 line-clamp-2 h-10">{product.description}</p>
                  
                  <div className="space-y-2 mb-6 flex-grow">
                    {product.features.map((feature, i) => (
                      <div key={i} className="flex items-center gap-2 text-xs text-slate-600">
                        <div className="w-1.5 h-1.5 rounded-full bg-[#F2B544]" />
                        {feature}
                      </div>
                    ))}
                  </div>

                  <button 
                    onClick={() => onProductSelect(product)}
                    className="w-full py-3 border border-[#0e253d] text-[#0e253d] font-bold rounded-lg hover:bg-[#0e253d] hover:text-white transition-all flex items-center justify-center gap-2 mt-auto"
                  >
                    View Details <ArrowRight size={16} />
                  </button>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>

        {filteredProducts.length === 0 && (
          <div className="text-center py-20">
            <p className="text-slate-400 text-lg">No products found matching your criteria.</p>
            <button 
              onClick={() => { setActiveCategory('All'); setSearchQuery(''); }}
              className="mt-4 text-[#F2B544] font-bold hover:underline"
            >
              Clear Filters
            </button>
          </div>
        )}
      </div>
      
      {/* Feature Strip */}
      <div className="bg-white border-t border-slate-100 py-12">
        <div className="max-w-7xl mx-auto px-4 grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
            <div className="flex flex-col items-center">
                <div className="w-12 h-12 bg-[#F2B544]/10 rounded-full flex items-center justify-center text-[#d99f33] mb-4">
                    <Wind size={24} />
                </div>
                <h4 className="font-bold text-[#0e253d]">High Air Delivery</h4>
                <p className="text-sm text-slate-500">Optimized blade angles for maximum airflow</p>
            </div>
            <div className="flex flex-col items-center">
                <div className="w-12 h-12 bg-[#F2B544]/10 rounded-full flex items-center justify-center text-[#d99f33] mb-4">
                    <Zap size={24} />
                </div>
                <h4 className="font-bold text-[#0e253d]">Energy Efficient</h4>
                <p className="text-sm text-slate-500">Low power consumption copper motors</p>
            </div>
            <div className="flex flex-col items-center">
                <div className="w-12 h-12 bg-[#F2B544]/10 rounded-full flex items-center justify-center text-[#d99f33] mb-4">
                    <ShieldCheck size={24} />
                </div>
                <h4 className="font-bold text-[#0e253d]">Durable Build</h4>
                <p className="text-sm text-slate-500">Anti-corrosive materials for long life</p>
            </div>
        </div>
      </div>
    </div>
  );
};