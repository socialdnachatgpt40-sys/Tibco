import React, { useEffect } from 'react';
import { motion } from 'framer-motion';
import { ChevronRight, Settings, Globe, Lightbulb, Hammer, CheckCircle2 } from 'lucide-react';
import { Clientele } from '../Clientele';
import { Contact } from '../Contact';

interface OEMPageProps {
  onNavigate: (view: string) => void;
}

export const OEMPage: React.FC<OEMPageProps> = ({ onNavigate }) => {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const features = [
    {
      title: "High-Quality Materials",
      description: "Use of CRCA blades, covers, and precision-engineered parts for long-lasting performance.",
      icon: Hammer
    },
    {
      title: "Advanced Engineering",
      description: "Products designed with high-speed and normal-speed motors for superior efficiency.",
      icon: Settings
    },
    {
      title: "International Standards",
      description: "Appliances tested and manufactured at four state-of-the-art plants in Noida (Uttar Pradesh).",
      icon: Globe
    },
    {
      title: "Innovation & Reliability",
      description: "Continuously adapting to new technologies to provide advanced, customer-friendly solutions.",
      icon: Lightbulb
    }
  ];

  const productRanges = [
    "Ceiling Fans & Table Fans",
    "TPW Fans",
    "Ventilation & Light Duty Exhaust Fans",
    "Heavy Duty Exhaust Fans"
  ];

  return (
    <div className="pt-24 min-h-screen bg-slate-50">
      {/* Header */}
      <div className="bg-[#0e253d] text-white py-16 px-4 md:px-8 relative overflow-hidden">
        <div className="max-w-7xl mx-auto relative z-10 text-center">
          <h1 className="text-4xl md:text-6xl font-serif font-bold mb-6">Quality Products For Brands</h1>
          <div className="flex justify-center items-center gap-2 text-sm text-slate-300">
            <button onClick={() => onNavigate('home')} className="hover:text-[#F2B544] transition-colors">Home</button>
            <ChevronRight size={14} />
            <span className="text-[#F2B544] font-medium">OEM Services</span>
          </div>
        </div>
      </div>

      {/* Intro Section */}
      <div className="max-w-7xl mx-auto px-4 md:px-8 py-20">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <motion.div initial={{ opacity: 0, x: -30 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }}>
            <span className="text-[#F2B544] font-bold tracking-widest uppercase text-sm">OEM Excellence</span>
            <h2 className="text-3xl md:text-4xl font-serif font-bold text-[#0e253d] mt-2 mb-6">
              Quality at the <span className="text-[#F2B544]">Heart of Creation</span>
            </h2>
            <div className="space-y-6 text-slate-600 text-lg leading-relaxed">
              <p>
                At <strong className="text-[#0e253d]">Tibco</strong>, quality has always been at the heart of everything we create. Since our inception in <strong className="text-[#0e253d]">1975</strong>, we have been committed to delivering <strong className="text-[#0e253d]">reliable, durable, and performance-driven electrical home appliances</strong> that meet both national and international standards.
              </p>
              <p>
                Over the decades, Tibco has grown from a small business into one of India’s most trusted brands, known for its ability to blend <strong className="text-[#0e253d]">advanced technology with superior craftsmanship</strong>. Every appliance we manufacture undergoes strict quality checks to ensure it meets the expectations of our customers as well as the evolving standards of the industry.
              </p>
            </div>
          </motion.div>
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }} 
            whileInView={{ opacity: 1, scale: 1 }} 
            viewport={{ once: true }}
            className="rounded-2xl overflow-hidden shadow-2xl border-4 border-white"
          >
            <img 
              src="https://tibcogroup.com/wp-content/uploads/2025/09/banner1-scaled.png" 
              alt="Tibco Manufacturing Quality" 
              className="w-full h-auto object-cover"
            />
          </motion.div>
        </div>
      </div>

      {/* What Makes Us Trusted */}
      <div className="bg-[#0e253d] text-white py-20">
        <div className="max-w-7xl mx-auto px-4 md:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-serif font-bold mb-4">What Makes Tibco a <span className="text-[#F2B544]">Trusted Choice?</span></h2>
            <div className="w-24 h-1 bg-[#F2B544] mx-auto rounded-full"></div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
                className="bg-white/5 backdrop-blur-sm border border-white/10 p-8 rounded-2xl hover:bg-white/10 transition-all duration-300"
              >
                <div className="w-14 h-14 bg-[#F2B544] rounded-full flex items-center justify-center text-[#0e253d] mb-6">
                  <feature.icon size={28} />
                </div>
                <h3 className="text-xl font-bold mb-3">{feature.title}</h3>
                <p className="text-slate-300 text-sm leading-relaxed">
                  {feature.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>

      {/* Product Range */}
      <div className="max-w-7xl mx-auto px-4 md:px-8 py-20">
        <div className="bg-white rounded-3xl p-10 md:p-16 shadow-xl border border-slate-100 text-center relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-[#F2B544] opacity-5 rounded-full blur-3xl"></div>
          <div className="absolute bottom-0 left-0 w-64 h-64 bg-[#0e253d] opacity-5 rounded-full blur-3xl"></div>
          
          <h2 className="text-3xl md:text-4xl font-serif font-bold text-[#0e253d] mb-8 relative z-10">Our Range of Quality Products</h2>
          <p className="text-slate-600 max-w-2xl mx-auto mb-12 relative z-10 text-lg">
            We manufacture and supply a wide range of electrical home appliances trusted by households and businesses alike:
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 relative z-10">
            {productRanges.map((range, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
                className="bg-slate-50 rounded-xl p-6 border border-slate-200 hover:border-[#F2B544] hover:shadow-lg transition-all"
              >
                <div className="w-10 h-10 bg-[#0e253d] rounded-full flex items-center justify-center text-white mb-4 mx-auto">
                  <CheckCircle2 size={20} />
                </div>
                <h3 className="font-bold text-[#0e253d]">{range}</h3>
              </motion.div>
            ))}
          </div>
          
          <div className="mt-12 relative z-10">
             <button onClick={() => onNavigate('products')} className="px-8 py-3 bg-[#F2B544] text-[#0e253d] font-bold rounded-full hover:bg-[#d99f33] transition-colors">
                View Full Catalog
             </button>
          </div>
        </div>
      </div>

      <Clientele />
      <Contact />
    </div>
  );
};