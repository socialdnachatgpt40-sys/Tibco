import React, { useEffect } from 'react';
import { motion } from 'framer-motion';
import { ArrowLeft, CheckCircle2, ChevronRight, Phone, Mail } from 'lucide-react';
import { Product } from '../../types';
import { Clientele } from '../Clientele';

interface ProductDetailPageProps {
  product: Product;
  onBack: () => void;
  onNavigate: (view: string) => void;
}

export const ProductDetailPage: React.FC<ProductDetailPageProps> = ({ product, onBack, onNavigate }) => {
  
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [product]);

  return (
    <div className="pt-24 min-h-screen bg-slate-50">
      {/* Breadcrumb Header */}
      <div className="bg-[#0e253d] text-white py-8 px-4 md:px-8">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center gap-2 text-sm text-slate-300">
          <button onClick={() => onNavigate('home')} className="hover:text-[#F2B544] transition-colors">Home</button>
          <ChevronRight size={14} />
          <button onClick={onBack} className="hover:text-[#F2B544] transition-colors">Products</button>
          <ChevronRight size={14} />
          <span className="text-[#F2B544] font-medium">{product.model}</span>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 md:px-8 py-12">
        <button 
          onClick={onBack}
          className="flex items-center gap-2 text-[#0e253d] font-bold mb-8 hover:text-[#F2B544] transition-colors group"
        >
          <ArrowLeft size={20} className="group-hover:-translate-x-1 transition-transform" /> Back to Products
        </button>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 mb-20">
          {/* Image Section */}
          <motion.div 
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            className="bg-white rounded-3xl p-8 md:p-12 shadow-xl border border-slate-100 flex items-center justify-center relative overflow-hidden h-fit"
          >
            <div className="absolute top-0 right-0 w-full h-full bg-radial-gradient from-slate-50 to-transparent opacity-50" />
            <img 
              src={product.image} 
              alt={product.name} 
              className="w-full h-auto object-contain max-h-[500px] relative z-10 drop-shadow-2xl transition-transform duration-700 hover:scale-105"
            />
            <div className="absolute bottom-6 left-6 z-20">
               <span className="bg-[#F2B544] text-[#0e253d] text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider">
                 {product.category}
               </span>
            </div>
          </motion.div>

          {/* Details Section */}
          <motion.div 
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
          >
            <h1 className="text-4xl md:text-5xl font-serif font-bold text-[#0e253d] mb-4">
              {product.model}
            </h1>
            <h2 className="text-xl text-slate-500 font-medium mb-6">{product.name}</h2>
            
            <p className="text-slate-600 leading-relaxed mb-8 text-lg">
              {product.description}
            </p>

            <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden mb-10">
              <div className="bg-slate-100 px-6 py-4 border-b border-slate-200">
                <h3 className="font-bold text-[#0e253d] flex items-center gap-2">
                  Technical Specifications
                </h3>
              </div>
              <div className="divide-y divide-slate-100">
                {product.detailedSpecs.map((spec, index) => (
                  <div key={index} className="grid grid-cols-2 hover:bg-slate-50 transition-colors">
                    <div className="px-6 py-4 text-sm font-semibold text-slate-600 bg-slate-50/50">
                      {spec.label}
                    </div>
                    <div className="px-6 py-4 text-sm font-medium text-[#0e253d]">
                      {spec.value}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-[#0e253d] text-white rounded-2xl p-8 relative overflow-hidden">
              <div className="absolute top-[-50%] right-[-10%] w-[200px] h-[200px] bg-[#F2B544] rounded-full blur-[80px] opacity-20"></div>
              
              <h3 className="text-2xl font-serif font-bold mb-4">Interested in this product?</h3>
              <p className="text-slate-300 mb-6">
                Contact us for bulk orders, OEM services, or dealership inquiries.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4">
                <a 
                  href="tel:+919281096258" 
                  className="flex items-center justify-center gap-2 bg-[#F2B544] hover:bg-[#d99f33] text-[#0e253d] font-bold py-3 px-6 rounded-lg transition-all"
                >
                  <Phone size={18} /> Call Now
                </a>
                <a 
                  href="#contact" 
                  onClick={(e) => { e.preventDefault(); onNavigate('#contact'); }}
                  className="flex items-center justify-center gap-2 bg-white/10 hover:bg-white/20 text-white font-bold py-3 px-6 rounded-lg transition-all border border-white/20"
                >
                  <Mail size={18} /> Send Enquiry
                </a>
              </div>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Clientele Scroller */}
      <Clientele />
    </div>
  );
};