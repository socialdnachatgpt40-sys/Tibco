import React from 'react';
import { motion } from 'framer-motion';
import { Section } from './ui/Section';
import { MapPin, Phone, Mail, Send } from 'lucide-react';

export const Contact: React.FC = () => {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert("Thank you! Your message has been sent successfully. We will get back to you shortly.");
  };

  return (
    <Section id="contact" dark className="!pb-0 bg-[#0e253d]">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-24 mb-20">
        <div>
          <span className="text-[#F2B544] font-bold tracking-widest uppercase text-sm">Get in Touch</span>
          <h2 className="text-4xl md:text-5xl font-serif font-bold text-white mt-4 mb-6">
            It's time to talk about <br/><span className="text-[#F2B544]">your project</span>
          </h2>
          <p className="text-slate-400 text-lg mb-12">
            Let’s embark on a creative journey together. We are ready to shape a visual narrative of your brand with our premium appliances.
          </p>

          <div className="space-y-8">
            <a href="tel:+919281096258" className="flex items-start gap-4 group">
              <div className="w-12 h-12 bg-white/5 border border-white/10 rounded-full flex items-center justify-center text-[#F2B544] group-hover:bg-[#F2B544] group-hover:text-[#0e253d] transition-all">
                <Phone size={20} />
              </div>
              <div>
                <h4 className="text-white font-bold text-lg">Call Us</h4>
                <p className="text-slate-400 font-manrope">+91 92810 96258</p>
              </div>
            </a>

            <a href="mailto:info@tibcogroup.com" className="flex items-start gap-4 group">
              <div className="w-12 h-12 bg-white/5 border border-white/10 rounded-full flex items-center justify-center text-[#F2B544] group-hover:bg-[#F2B544] group-hover:text-[#0e253d] transition-all">
                <Mail size={20} />
              </div>
              <div>
                <h4 className="text-white font-bold text-lg">Email Us</h4>
                <p className="text-slate-400">info@tibcogroup.com</p>
              </div>
            </a>

            <div className="flex items-start gap-4 group">
              <div className="w-12 h-12 bg-white/5 border border-white/10 rounded-full flex items-center justify-center text-[#F2B544] group-hover:bg-[#F2B544] group-hover:text-[#0e253d] transition-all">
                <MapPin size={20} />
              </div>
              <div>
                <h4 className="text-white font-bold text-lg">Visit Us</h4>
                <p className="text-slate-400 max-w-xs">
                  B-66, Assisted Private Industrial Estate, IDA, Balanagar, Hyderabad, Telangana 500037
                </p>
              </div>
            </div>
          </div>
        </div>

        <motion.div
          initial={{ opacity: 0, x: 30 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          className="bg-white rounded-2xl p-8 md:p-10 shadow-2xl relative overflow-hidden"
        >
          <h3 className="text-2xl font-bold text-[#0e253d] mb-6">Send Message</h3>
          <form className="space-y-5" onSubmit={handleSubmit}>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              <div className="space-y-1">
                <input 
                  type="text" 
                  required
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-3 text-slate-800 focus:outline-none focus:border-[#F2B544] focus:ring-1 focus:ring-[#F2B544] transition-all"
                  placeholder="Your Name"
                />
              </div>
              <div className="space-y-1">
                <input 
                  type="email" 
                  required
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-3 text-slate-800 focus:outline-none focus:border-[#F2B544] focus:ring-1 focus:ring-[#F2B544] transition-all"
                  placeholder="Email Address"
                />
              </div>
            </div>
            
            <div className="space-y-1">
              <input 
                type="text" 
                required
                className="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-3 text-slate-800 focus:outline-none focus:border-[#F2B544] focus:ring-1 focus:ring-[#F2B544] transition-all"
                placeholder="Subject"
              />
            </div>

            <div className="space-y-1">
              <textarea 
                rows={4}
                required
                className="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-3 text-slate-800 focus:outline-none focus:border-[#F2B544] focus:ring-1 focus:ring-[#F2B544] transition-all"
                placeholder="Message in brief..."
              ></textarea>
            </div>

            <button 
              type="submit"
              className="w-full bg-[#0e253d] hover:bg-[#1a3c5e] text-white font-bold py-4 rounded-lg transition-all flex items-center justify-center gap-2 group shadow-lg hover:shadow-xl transform hover:-translate-y-0.5"
            >
              Send Message
              <Send size={18} className="group-hover:translate-x-1 transition-transform" />
            </button>
          </form>
        </motion.div>
      </div>

      {/* Map Placeholder */}
      <div className="w-full h-80 rounded-t-3xl overflow-hidden filter grayscale hover:grayscale-0 transition-all duration-700 relative z-10 border-t-4 border-[#F2B544]">
        <iframe 
          src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3806.305739343719!2d78.4357773!3d17.4477033!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bcb90c8a0000001%3A0x0!2sHyderabad%2C%20Telangana!5e0!3m2!1sen!2sin!4v1699999999999" 
          width="100%" 
          height="100%" 
          style={{ border: 0 }} 
          allowFullScreen 
          loading="lazy" 
          referrerPolicy="no-referrer-when-downgrade"
        ></iframe>
      </div>
    </Section>
  );
};