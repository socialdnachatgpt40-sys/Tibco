import React from 'react';
import { motion } from 'framer-motion';
import { Section } from './ui/Section';
import { FeaturedProduct } from '../types';

interface ProjectsProps {
  onNavigate: (view: string) => void;
}

const featuredProducts: FeaturedProduct[] = [
  { 
    id: '1', 
    model: 'TT-01', 
    title: 'Pedestal Fan', 
    description: 'Engineered for comfort and performance.', 
    image: 'https://tibcogroup.com/wp-content/uploads/2025/09/tibco-banner1.jpg',
    category: 'Pedestal'
  },
  { 
    id: '2', 
    model: 'TP-01', 
    title: 'Modern Pedestal', 
    description: 'Combines durability with modern design.', 
    image: 'https://tibcogroup.com/wp-content/uploads/2025/09/tibco-banner2.jpg',
    category: 'Pedestal'
  },
  { 
    id: '3', 
    model: 'TCF-03', 
    title: 'Ceiling Fan', 
    description: 'Powerful cooling with sweep sizes of 900mm.', 
    image: 'https://tibcogroup.com/wp-content/uploads/2025/09/tibco-banner3.jpg',
    category: 'Ceiling'
  },
  { 
    id: '4', 
    model: 'TEX-HS09', 
    title: 'Exhaust Fan', 
    description: 'Compact 9-inch high-speed metal exhaust fan.', 
    image: 'https://tibcogroup.com/wp-content/uploads/2025/09/tibco-banner4.jpg',
    category: 'Exhaust'
  },
];

export const Projects: React.FC<ProjectsProps> = ({ onNavigate }) => {
  const handleDownload = (e: React.MouseEvent) => {
    e.preventDefault();
    alert("Catalogue download starting...");
  };

  return (
    <Section id="featured" className="bg-slate-50">
      <div className="flex flex-col md:flex-row justify-between items-end mb-12">
        <div className="max-w-2xl">
           <span className="text-[#F2B544] font-bold tracking-widest uppercase text-sm">For Brands</span>
           <h2 className="text-4xl md:text-5xl font-serif font-bold text-[#0e253d] mt-4">
             Quality Products <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#0e253d] to-[#F2B544]">For Brands</span>
           </h2>
        </div>
        
        <button 
          onClick={handleDownload}
          className="hidden md:inline-block px-6 py-3 border border-[#0e253d] text-[#0e253d] font-bold rounded-full hover:bg-[#0e253d] hover:text-white transition-all"
        >
          Download Catalogue
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {featuredProducts.map((product, idx) => (
          <motion.div
            key={product.id}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: idx * 0.1 }}
            className="group relative overflow-hidden rounded-2xl shadow-lg bg-white cursor-pointer"
            onClick={() => onNavigate('products')}
          >
            <div className="aspect-[16/9] overflow-hidden">
                <img 
                    src={product.image} 
                    alt={product.title} 
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                />
            </div>
            <div className="absolute inset-0 bg-gradient-to-t from-[#0e253d] via-transparent to-transparent opacity-90"></div>
            
            <div className="absolute bottom-0 left-0 w-full p-8 text-white">
                <div className="flex items-center justify-between mb-2">
                    <span className="text-[#F2B544] font-bold text-sm tracking-wider uppercase">{product.model}</span>
                    <span className="bg-white/20 px-2 py-1 rounded text-xs backdrop-blur-sm">{product.category}</span>
                </div>
                <h3 className="text-2xl font-bold mb-2 group-hover:text-[#F2B544] transition-colors">{product.title}</h3>
                <p className="text-slate-300 text-sm max-w-md">{product.description}</p>
            </div>
          </motion.div>
        ))}
      </div>
      
      <div className="text-center mt-12 md:hidden">
        <button 
          onClick={handleDownload}
          className="px-8 py-3 border-2 border-[#0e253d] text-[#0e253d] font-bold rounded-full hover:bg-[#0e253d] hover:text-white transition-all"
        >
          Download Catalogue
        </button>
      </div>
    </Section>
  );
};